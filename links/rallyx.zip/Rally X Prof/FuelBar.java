import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class FuelBar extends ScrollActor
{
    public void act() 
    {
        int ts = Scoreboard.getFuel() / 10 * 10;
        int h = Scoreboard.getFuel() / 10;
        if(h == 10){
            setImage("Fuel10.png");
        }
        else{
            setImage("Fuel" + (h + 1) + ".png");
        }
        if(Scoreboard.getFuel() > 0){
            getImage().scale(ts + 20 +(h * 3),60);
        }
        else{
            getImage().scale(1,1);
        }
        setLocation(Scoreboard.getx() - ((100 - ts)/ 2) + h,Scoreboard.gety() + 200);
    }    
}
