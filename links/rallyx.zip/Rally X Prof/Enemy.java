import greenfoot.*;
public class Enemy extends Car implements Moveable
{
    private int speed;
    private static boolean flag;
    private boolean flag2;
    private Object left;
    private Object right;
    private Object up;
    private Object down;
    private Object leftFar; 
    private Object rightFar;
    private Object upFar;
    private Object downFar;
    private final int CHECK;
    private final int CHECKFAR;
    private static SimpleTimer timer;
    private SimpleTimer timer2;
    private int rot;
    private final int NUM;
    public Enemy(int num){
        speed = 8;
        getImage().scale(50,30);
        left = null;
        right = null;
        down = null;
        up = null;
        leftFar = null;
        rightFar = null;
        downFar = null;
        upFar = null;
        flag = false;
        flag2 = false;
        CHECK = 40;
        CHECKFAR = 70;
        timer = new SimpleTimer();
        timer.mark();
        timer2 = new SimpleTimer();
        timer2.mark();
        rot = 0;
        NUM = num;
    }

    public void act() 
    {
        if(!flag){
            if(timer.millisElapsed() > 4000){
                if(timer2.millisElapsed() > 3000){
                    movement();
                }
                if(isTouching(Oil.class) || flag2){
                    if(flag2){
                        oiled();                        
                    }
                    else{
                        timer2.mark();
                        flag2 = true;
                        rot = getRotation();
                    }
                }
                
                left = getOneObjectAtOffset(-CHECK,0,Wall.class);
                right = getOneObjectAtOffset(CHECK,0,Wall.class);
                up = getOneObjectAtOffset(0,-CHECK,Wall.class);
                down = getOneObjectAtOffset(0,CHECK,Wall.class);
                leftFar = getOneObjectAtOffset(-CHECKFAR,0,Wall.class);
                rightFar = getOneObjectAtOffset(CHECKFAR,0,Wall.class);
                upFar = getOneObjectAtOffset(0,-CHECKFAR,Wall.class);
                downFar = getOneObjectAtOffset(0,CHECKFAR,Wall.class);
            }
            else{
                if(NUM == 2){
                    setRotation(180);
                }
                else{
                    setRotation(0);
                }
            }
        }
        else{
            if(timer.millisElapsed() > 1000){
                flag = false;
                timer.mark();
            }
        }
    } 

    public void movement(){
        move(speed);

        if(getRot() == 0 && right != null){
            if(User.gety() >= getY()){
                if(Math.abs(User.gety() - getY()) < 70 && leftFar == null){
                    setRotation(180);
                }
                else if(downFar == null){
                    setRotation(90);
                }
                else if(upFar == null){
                    setRotation(270);
                }

                else{
                    setRotation(180);
                }
            }
            else{
                if(Math.abs(User.gety() - getY()) < 70 && leftFar == null){
                    setRotation(180);
                }
                else if(upFar == null){
                    setRotation(270);
                }
                else if(downFar == null){
                    setRotation(90);
                }
                else{
                    setRotation(180);
                }
            }
        }
        else if(getRot() == 90 && down != null){
            if(User.getx() >= getX()){
                if(Math.abs(User.getx() - getX()) < 70 && upFar == null){
                    setRotation(270);
                }
                else if(rightFar == null){
                    setRotation(0);
                }
                else if(leftFar == null){
                    setRotation(180);
                }
                else{
                    setRotation(270);
                }
            }
            else{
                if(Math.abs(User.getx() - getX()) < 70 && upFar == null){
                    setRotation(270);
                }
                else if(leftFar == null){
                    setRotation(180);
                }
                else if(rightFar == null){
                    setRotation(0);
                }
                else{
                    setRotation(270);
                }
            }
        }
        else if(getRot() == 180 && left != null){
            if(User.gety() >= getY()){
                if(Math.abs(User.gety() - getY()) < 70 && rightFar == null){
                    setRotation(0);
                }
                else if(downFar == null){
                    setRotation(90);
                }
                else if(upFar == null){
                    setRotation(270);
                }
                else{
                    setRotation(0);
                }
            }
            else{
                if(Math.abs(User.gety() - getY()) < 70 && rightFar == null){
                    setRotation(0);
                }
                else if(upFar == null){
                    setRotation(270);
                }
                else if(downFar == null){
                    setRotation(90);
                }
                else{
                    setRotation(0);
                }
            }
        }
        else if(getRot() == 270 && up != null){
            if(User.getx() >= getX()){
                if(Math.abs(User.getx() - getY()) < 70 && downFar == null){
                    setRotation(90);
                }
                else if(rightFar == null){
                    setRotation(0);
                }
                else if(leftFar == null){
                    setRotation(180);
                }
                else{
                    setRotation(90);
                }
            }
            else{
                if(Math.abs(User.getx() - getY()) < 70 && downFar == null){
                    setRotation(90);
                }
                else if(leftFar == null){
                    setRotation(180);
                }
                else if(rightFar == null){
                    setRotation(0);
                }
                else{
                    setRotation(90);
                }

            }
        }

    }

    public void guided(){
    }

    public void oiled(){
        if(timer2.millisElapsed() < 3000){
            turn(5);
        }
        else{
            flag2 = false;
            setRotation(rot);
        }
    }

    public void nearWall(){ 
    }

    public static void waitt(){
        timer.mark();
        flag = true;
    }

    public int getRot(){
        return getRotation();
    }
    
}
