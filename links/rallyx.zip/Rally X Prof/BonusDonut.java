import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class BonusDonut extends Donut
{
    public BonusDonut(){
        getImage().scale(60,50);
    }
    public void act() 
    {
        touchUser();
    } 
    public void touchUser(){
        if(isTouching(User.class)){
            getWorld().removeObject(this);
            Scoreboard.upScore();
            Scoreboard.bonus();
        }
    }
}
