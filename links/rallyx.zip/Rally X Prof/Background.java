import greenfoot.*;
import java.util.*;
import java.io.*;

public class Background extends ScrollWorld
{
    private static List<Donut> currentDonuts = new ArrayList<Donut>();
    //private static List<Enemy> todos = new ArrayList<Enemy>();
    //private static List<ScrollActor> small = new ArrayList<ScrollActor>();
    private static User Control;
    private static Enemy bad1;
    private static Enemy bad2;
    private static boolean flag = false;
    private static GreenfootSound music;
    private static MiniMap map;
    private SmallEnemy un;
    private SmallEnemy dos;
    private SmallUser sing;
    public Background()
    {
        super(1000, 500, 1, 4000, 2000);
        
        music = new GreenfootSound("Theme.mp3");
        //music.play();
        Control = new User();
        addCameraFollower(Control, -100, 0);
        bad1 = new Enemy(1);
        addObject(bad1,1000,520);
        bad2 = new Enemy(2);
        addObject(bad2,1000,250);
        Wall Top = new Wall();
        addObject(Top, 2000 ,112);
        Top.getImage().scale(3500,245);
        Wall Rside = new Wall();
        addObject(Rside,3200,1000);
        Rside.getImage().scale(400,2000);
        Wall Lside = new Wall();
        addObject(Lside,175,1000);
        Lside.getImage().scale(400,2000);
        Wall Bot = new Wall();
        addObject(Bot,2000,1980);
        Bot.getImage().scale(3500,400);

        Wall a = new Wall();
        addObject(a,450,320);
        a.getImage().scale(500,70);
        Wall b = new Wall();
        addObject(b,805,500);
        b.getImage().scale(70,600);
        Wall c = new Wall();
        addObject(c,665,500);
        c.getImage().scale(70,290);
        Wall d = new Wall();
        addObject(d,500,530);
        d.getImage().scale(130,225);
        Wall e = new Wall();
        addObject(e,470,840);
        e.getImage().scale(70,450);
        Wall f = new Wall();
        addObject(f,470,1420);
        f.getImage().scale(70,600);
        Wall h = new Wall();
        addObject(h,1158,320);
        h.getImage().scale(500,70);
        Wall i = new Wall();
        addObject(i,1158,450);
        i.getImage().scale(500,70);
        Wall j = new Wall();
        addObject(j,635,900);
        j.getImage().scale(130,400);
        Wall k = new Wall();
        addObject(k,635,1440);
        k.getImage().scale(130,560);        
        Wall l = new Wall();
        addObject(l,920,1680);
        l.getImage().scale(300,65);
        Wall m = new Wall();
        addObject(m,805,1160);
        m.getImage().scale(70,600);        
        Wall n = new Wall();
        addObject(n,1210,935);
        n.getImage().scale(600,150);        
        Wall o = new Wall();
        addObject(o,1475,1250);
        o.getImage().scale(70,500);
        Wall p = new Wall();
        addObject(p,1140,1260);
        p.getImage().scale(450,250);        
        Wall q = new Wall();
        addObject(q,1140,1520);
        q.getImage().scale(740,150);
        Wall r = new Wall();
        addObject(r,1500,1680);
        r.getImage().scale(700,65);
        Wall s = new Wall();
        addObject(s,1660,1225);
        s.getImage().scale(150,730);
        Wall t = new Wall();
        addObject(t,1260,670);
        t.getImage().scale(700,150);        
        Wall u = new Wall();
        addObject(u,1575,540);
        u.getImage().scale(70,250);        
        Wall v = new Wall();
        addObject(v,1730,320);
        v.getImage().scale(500,70);
        Wall w = new Wall();
        addObject(w,1715,605);
        w.getImage().scale(70,375);
        Wall x = new Wall();
        addObject(x,2060,495);
        x.getImage().scale(500,150);
        Wall y = new Wall();
        addObject(y,1960,640);
        y.getImage().scale(300,300);
        Wall z = new Wall();
        addObject(z,1960,1225);
        z.getImage().scale(300,730);       
        Wall aa = new Wall();
        addObject(aa,2245,705);
        aa.getImage().scale(130,160);
        Wall bb = new Wall();
        addObject(bb,2280,1225);
        bb.getImage().scale(200,730);
        Wall cc = new Wall();
        addObject(cc,2075,1600);
        cc.getImage().scale(70,200);
        Wall dd = new Wall();
        addObject(dd,2300,320);
        dd.getImage().scale(500,70);
        Wall ee = new Wall();
        addObject(ee,2650,1750);
        ee.getImage().scale(700,70);
        Wall ff = new Wall();
        addObject(ff,2650,1620);
        ff.getImage().scale(400,70);
        Wall gg = new Wall();
        addObject(gg,2815,1265);
        gg.getImage().scale(70,500);
        Wall hh = new Wall();
        addObject(hh,2525,1055);
        hh.getImage().scale(350,70);
        Wall ii = new Wall();
        addObject(ii,2620,1195);
        ii.getImage().scale(350,70);
        Wall jj = new Wall();
        addObject(jj,2525,1335);
        jj.getImage().scale(350,70);
        Wall kk = new Wall();
        addObject(kk,2620,1480);
        kk.getImage().scale(350,70);
        Wall ll = new Wall();
        addObject(ll,2720,320);
        ll.getImage().scale(350,70);
        Wall mm = new Wall();
        addObject(mm,2900,535);
        mm.getImage().scale(70,500);
        Wall nn = new Wall();
        addObject(nn,2585,455);
        nn.getImage().scale(425,70);
        Wall oo = new Wall();
        addObject(oo,2763,635);
        oo.getImage().scale(70,300);
        Wall pp = new Wall();
        addObject(pp,2550,750);
        pp.getImage().scale(225,400);
        Wall qq = new Wall();
        addObject(qq,3000,950);
        qq.getImage().scale(180,70);
        Wall rr = new Wall();
        addObject(rr,3000,1200);
        rr.getImage().scale(180,70);
        Wall ss = new Wall();
        addObject(ss,3000,1450);
        ss.getImage().scale(180,70);

        Donut da = new Donut();
        addObject(da,400,1750);
        Donut db = new Donut();
        addObject(db,1550,1615);
        Donut dc = new Donut();
        addObject(dc,1780,580);
        Donut de = new Donut();
        addObject(de,1400,1050);
        FuelDonut df = new FuelDonut();
        addObject(df,2410,1170);
        Donut dg = new Donut();
        addObject(dg,2960,1330);
        Donut dh = new Donut();
        addObject(dh,2600,1680);
        Donut di = new Donut();
        addObject(di,400,400);
        Donut dj = new Donut();
        addObject(dj,1770,1315);
        Donut dk = new Donut();
        addObject(dk,870,280);
        Donut dl = new Donut();
        addObject(dl,2970,270);
        Donut dm = new Donut();
        addObject(dm,2830,390);
        Donut dn = new Donut();
        addObject(dn,1480,540);
        Donut dO = new Donut();
        addObject(dO,2140,600);
        Donut dp = new Donut();
        addObject(dp,535,1100);
        Donut dq = new Donut();
        addObject(dq,1260,780);
        BonusDonut dr = new BonusDonut();
        addObject(dr,1110,1685);

        Scoreboard score = new Scoreboard();
        addObject(score,900,250);
        score.getImage().scale(200,500);
        map = new MiniMap();
        addObject(map,900,250);
        map.getImage().scale(180,90);
        un = new SmallEnemy();
        addObject(un,900,250);
        un.getImage().scale(7,7);
        dos = new SmallEnemy();
        addObject(dos,900,250);
        dos.getImage().scale(7,7);
        sing = new SmallUser();
        addObject(sing,900,250);
        sing.getImage().scale(7,7);
        FuelBar bar = new FuelBar();
        addObject(bar,900,450);
        bar.getImage().scale(150,60);
        

        currentDonuts = getObjects(Donut.class);
        //todos = getObjects(Enemy.class);
        
        
        //System.out.print(currentWalls.size());
    }
    
    public static List<Donut> getDonuts(){
        return currentDonuts;
    }

    public static void reset(){
        if(!flag){
            flag = true;
        }
        else{
            Control.setLocation(400, 250);
            bad1.setLocation(1000,390);
            bad2.setLocation(1000,250);
            flag = false;
            music.stop();
            //music.play();
        }

    }

    public void act(){
        currentDonuts = getObjects(Donut.class);
        /*small = MiniMap.getSmall();
        for(ScrollActor b: MiniMap.getSmall()){
            removeObject(b);
        }
        todos = getObjects(Actor.class);
        for(Actor a: todos){
            
        }
        */
        un.setLocation(User.getx() + 410 + bad1.getGlobalX() / 22,User.gety() - 45 + bad1.getGlobalY() / 22);
        dos.setLocation(User.getx() + 410 + bad2.getGlobalX() / 22,User.gety() - 45 + bad2.getGlobalY() / 22);
        sing.setLocation(User.getx() + 410 + Control.getGlobalX() / 22,User.gety() - 45 + Control.getGlobalY() / 22);
        if(flag == true){
            setCameraLocation(500,250);
            Background.reset();
        }
    }
    
    public static GreenfootSound getMusic(){
        return music;
    }
    
    public static User getUser(){
        return Control;
    }
}