import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class MiniMap here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MiniMap extends Actor
{
    private static List<ScrollActor> small = new ArrayList<ScrollActor>();
    public void act() 
    {
        setLocation(User.getx() + 500,User.gety());
        small = getIntersectingObjects(ScrollActor.class);
    }
    public static List<ScrollActor> getSmall(){
        return small;
    }
}
