import greenfoot.*;

/**
 * Write a description of class User here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class User extends Car implements Moveable
{
    private int speed;
    private SimpleTimer timer;
    private static SimpleTimer timer2;
    private static SimpleTimer timer3;
    private int guide;
    private boolean flag;
    private static boolean flag2;
    private static int rott;
    private static int x;
    private static int y;
    private Object right;
    private Object left;
    private Object up;
    private Object down;
    private final int CHECK;
    public User(){
        this.getImage().scale(50,30);
        speed = 7;
        guide = 30;
        timer = new SimpleTimer();
        timer.mark();
        timer2 = new SimpleTimer();
        timer2.mark();
        timer3 = new SimpleTimer();
        timer3.mark();
        flag = false;
        flag2 = false;
        right = null;
        left = null;
        up = null;
        down = null;
        CHECK = 20;
    }

    public void act() 
    {     
        if(timer2.millisElapsed() > 1000 || flag2 != true){
            nearWall();
            touchEnemy();
            if(timer.millisElapsed() > 100 && flag){
                flag = false;
            }
            if(!flag){
                movement();
                timer.mark();;
            }
            left = getOneObjectAtOffset(-CHECK,0,Wall.class);
            right = getOneObjectAtOffset(CHECK,0,Wall.class);
            up = getOneObjectAtOffset(0,-CHECK,Wall.class);
            down = getOneObjectAtOffset(0,CHECK,Wall.class);
        }
        else{
            setRotation(0);
        }
        x = getX();
        y = getY();
    } 

    public void movement(){
        getWorld().setCameraDirection(getRotation());
        getWorld().moveCamera(speed);
        if(Greenfoot.isKeyDown("up")){
            setRotation(270);
        }
        if(Greenfoot.isKeyDown("down")){
            setRotation(90);
        }
        if(Greenfoot.isKeyDown("left")){
            setRotation(180); 
        }
        if(Greenfoot.isKeyDown("right")){
            setRotation(0);
        }
        if(timer3.millisElapsed() > 200 && Greenfoot.isKeyDown("space")){
            Oil a = new Oil();
            if(getRot() == 0) getWorld().addObject(a,this.getGlobalX() - 30,this.getGlobalY());
            if(getRot() == 90) getWorld().addObject(a,this.getGlobalX(),this.getGlobalY() - 30);
            if(getRot() == 180) getWorld().addObject(a,this.getGlobalX() + 30,this.getGlobalY());
            if(getRot() == 270) getWorld().addObject(a,this.getGlobalX(),this.getGlobalY() + 30);
            Scoreboard.oilFuel();
            timer3.mark();
        }
    }

    public void nearWall(){
        if(getRot() == 0 && right != null){
            setRotation(180);
            flag = true;
        }
        else if(getRot() == 90 && down != null){
            setRotation(270);
            flag = true;
        }
        if(getRot() == 180 && left != null){
            setRotation(0);
            flag = true;
        }
        if(getRot() == 270 && up != null){
            setRotation(90);
            flag = true;
        }
    }

    public void touchEnemy(){
        if(this.isTouching(Enemy.class)){
            Scoreboard.subLives();
        }
    }

    public int getRot(){
        return getRotation();
    }

    public static int getx(){
        return x;
    }

    public static int gety(){
        return y;
    }

    public void smoked(){

    }

    public static void waitt(){
        timer2.mark();
        flag2 = true;
    }
}
