import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.io.*;
import java.util.*;
public class Scoreboard extends ScrollActor
{
    private static int score;
    private static int fuel;
    private static int lives;
    private SimpleTimer timer;
    private static int x;
    private static int y;
    private static int count;
    private static int highScore;
    private File hScore;
    private FileWriter fWriter;
    public Scoreboard(){
        getImage().scale(1,1);
        score = 0;
        fuel = 100;
        lives = 3;
        timer = new SimpleTimer();
        timer.mark();
        x = 0;
        y = 0;
        count = 5;
        highScore = 0;
    }

    public void act() 
    {
        fuelLoss();
        setLocation(User.getx() + 500,User.gety());
        if(lives > 0 && Background.getDonuts().size() != 0){
            getWorld().showText("Score: " + score, 900, 20);
            getWorld().showText("Lives: " + lives, 900, 40);
            getWorld().showText("Bonus: " + (5 - count) + " left", 900, 60);
            getWorld().showText("Fuel: " , 900, 400);
        }
        else{
            getWorld().showText("", 900, 20);
            getWorld().showText("", 900, 40);
            getWorld().showText("", 900, 60);
            getWorld().showText("", 900, 400);
            checkLives();
        }
        x = getX();
        y = getY();
        if(fuel <= 0){
            Scoreboard.subLives();
        }

    }

    public static void upScore(){
        score += 100;
        if(count < 5){
            score += 100;
            count ++;
        }
    }

    public static void fuelScore(){
        score += (fuel * 10);
    }

    public void fuelLoss(){
        if(timer.millisElapsed() > 700){
            fuel --;
            timer.mark();
        }
        
    }

    public static void oilFuel(){
        fuel -= 5;
    }

    public static int getFuel(){
        return fuel;
    }

    public static int getx(){
        return x;
    }

    public static int gety(){
        return y;
    }

    public static void subLives(){
        lives --;
        Background.reset();
        User.waitt();
        Enemy.waitt();
        count = 5;
        fuel = 101;
    }

    public void checkLives(){
            Background.getMusic().stop();
            score += lives * 1000;
            try{
                Scanner reader = new Scanner("h.txt");
                hScore = new File(reader.nextLine());
                reader = new Scanner(hScore);
                fWriter = new FileWriter(hScore);
                while(reader.hasNextInt()){
                    highScore = reader.nextInt();
                    System.out.println(highScore);
                }
                if(score > highScore){
                    fWriter.write("" + score);
                    highScore = score;
                }
                fWriter.flush();
                getWorld().setCameraLocation(2000,1000);
                Background.getUser().setLocation(2000,1000);
                EndScreen es = new EndScreen();
                getWorld().addObject(es, 500, 500);
                getWorld().showText("" + score, 530, 260);
                getWorld().showText("" + highScore, 530, 320);
               
            }
            catch(IOException e)
            {
                e.printStackTrace();
                System.err.print("Can't");
            }
            Greenfoot.stop();
     
    }

    public static void bonus(){
        count = 0;
    }
}
