import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class FuelDonut extends Donut
{
    public FuelDonut(){
        getImage().scale(40,40);
    }
    public void act() 
    {
        touchUser();
    } 
    public void touchUser(){
        if(isTouching(User.class)){
            getWorld().removeObject(this);
            Scoreboard.fuelScore();
        }
    }
}    

