import greenfoot.*;

public class EndScreen extends Actor
{
    public EndScreen(){
    }
    public void act() 
    {
        
    }    
}
