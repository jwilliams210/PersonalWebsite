import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Donut extends ScrollActor implements Scorable
{
    public Donut(){
        getImage().scale(50,50);
    }
    public void act() 
    {
        touchUser();
    } 
    public void touchUser(){
        if(isTouching(User.class)){
            getWorld().removeObject(this);
            Scoreboard.upScore();
        }
    }
}
