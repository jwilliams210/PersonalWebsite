import greenfoot.*;

public class Wall extends ScrollActor
{
    
    public void act() 
    {
        
    }
    
}
