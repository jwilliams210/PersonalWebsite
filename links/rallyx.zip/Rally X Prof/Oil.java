import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Oil extends ScrollActor
{
    private SimpleTimer timer;
    public Oil(){
        timer = new SimpleTimer();
        timer.mark();
        getImage().scale(50,50);
    }
    public void act() 
    {
        if(timer.millisElapsed() > 1500){
            getWorld().removeObject(this);
        }
    }    
}
