
public interface Scorable  
{
    public void touchUser();
}
