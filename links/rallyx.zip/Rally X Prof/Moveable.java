
public interface Moveable  
{
    public void movement();
}
